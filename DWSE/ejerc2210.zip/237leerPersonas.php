<?php
$cantidad = $_POST["cant"];

echo "<form action=\"237gestionarPersonas.php\" method=\"POST\" style=\"border:1px solid black; padding: 10px; border-radius:10px; display: inline-block;\">";
for ($i = 0; $i < $cantidad; $i++) {
    $aux = $i+1;
    echo "<p>Persona $aux</p>";
    echo "<label for=\"nombre\">Nombre </label><input id=\"nombre\" name=\"nombres[]\" type=\"text\">
    <br>";
    echo "<label for=\"altura\">Altura </label><input id=\"altura\" name=\"alturas[]\" type=\"text\">
    <br>";
    echo "<label for=\"email\">Email </label><input id=\"email\" name=\"emails[]\" type=\"email\">
    <br>";
}
echo "<br>";
echo "<button type=\"submit\">Enviar</button>";
echo "</form>";