<?php
$tabla = [];
$numeros = [];

for ($i = 0; $i < 6; $i++) {
    for ($j = 0; $j < 9; $j++) {
        do {
            $num = rand(100, 999);
        } while (in_array($num, $numeros));
        
        $tabla[$i][$j] = $num;
        $numeros[] = $num;
    }
}

$max = $tabla[0][0];
$min = $tabla[0][0];
$coordMax = [0, 0];
$coordMin = [0, 0];


for ($i = 0; $i < 6; $i++) {
    for ($j = 0; $j < 9; $j++) {
        if ($max < $tabla[$i][$j]){
            $max = $tabla[$i][$j];
            $coordMax = [$i, $j];
        }
        if ($min > $tabla[$i][$j]) {
            $min = $tabla[$i][$j];
            $coordMin = [$i, $j];

        }
    }
}

echo "<table border = 1>";
for ($i = 0; $i < 6; $i++) {
    echo "<tr>";
    for ($j = 0; $j < 9; $j++) {
        if ($j == $coordMax[1]) {
            echo "<td style=\"background-color: blue\">" . $tabla[$i][$j] . "</td>";
        } else if ($i == $coordMin[0]) {
            echo "<td style=\"background-color: green\">" . $tabla[$i][$j] . "</td>";
        } else {
            echo "<td>" . $tabla[$i][$j] . "</td>";
        }
    }
    echo "</tr>";
}
echo "</table>";