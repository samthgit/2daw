<?php
// $pregunta = $_POST["preg"];

$listaResp = ["Si", "No", "Quizás", "Claro que sí", "Por supuesto que no", 
"No lo tengo claro", "Seguro", "Yo diría que sí", "Ni de coña"];

$i = array_rand($listaResp);
$respuesta = $listaResp[$i];

echo $respuesta;