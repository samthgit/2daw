<?php
$nombres = $_POST["nombres"];
$alturas = $_POST["alturas"];
$emails = $_POST["emails"];
$lengthTabla = count($nombres);
$tabla = [];
$altMax = 0;
$altMin = 0;

$coordMax = [0,0];
$coordMin = [0,0];

for ($i = 0; $i < count($alturas); $i++) {
    if ($altMax < $alturas[$i]) {
        $altMax = $alturas[$i];
    }
    if ($altMin > $alturas[$i]) {
        $altMin = $alturas[$i];
    }
}

for ($i = 0; $i < $lengthTabla; $i++) {
    for ($j = 0; $j < 3; $j++) {
        if ($j == 0) {
            $tabla[$i][$j] = $nombres[$i];
        } else if ($j == 1) {
            $tabla[$i][$j] = $alturas[$i];
        } else if ($j == 2) {
            $tabla[$i][$j] = $emails[$i];
        }
        if ($alturas[$i] == $altMax) {
            $coordMax = [$i, $j];
        } else if ($alturas[$i] == $altMin) {
            $coordMin = [$i, $j];
        }
    }

}


echo "<table border = 1>";
echo "<tr>";
echo "<td>Nombre</td>";
echo "<td>Altura</td>";
echo "<td>Email</td>";
echo "</tr>";
for ($i = 0; $i < $lengthTabla; $i++) {
    echo "<tr>";
    for ($j = 0; $j < 3; $j++) {
        if ($i == $coordMax[0] || $i == $coordMin[0]) {
            echo "<td style=\"font-weight: bold\">" . $tabla[$i][$j] . "</td>";
        } else {
            echo "<td>" . $tabla[$i][$j] . "</td>";
        }
    }
    echo "</tr>";
}
echo "</table>";
