<?php
/*
 * Creamos la variable, que recibe por parámetros los números
 * del formulario anterior. Los almacena en un array.
*/
$numeros = $_POST["numero"];

/* 
 * Funcion auxiliar para printear de una manera más visible
 * los arrays.
*/
function printeoArrays($arrayP) {
    /*
     * Un for que simplemente modifica un poco el echo
     * según la posición que ocupa el elemento para hacerlo
     * más visual.
     */
    for ($i = 0; $i < count($arrayP); $i++) {
        if ($i == 0) {
            echo "[" . $arrayP[$i] . ",";
        } else if ($i == (count($arrayP)-1)) {
            echo $arrayP[$i] . "]";
        } else {
            echo $arrayP[$i] . ",";
        }
    }
}

/*
 * PRIMER EJERCICIO
 * Función que modifica un array que creamos dentro de la misma
 * y lo imprime por pantalla haciendo uso de la función printeoArray()
 * que creamos anteriormente.
 */
function arrayMod($arrayP) {
    /*
     * Creamos el array y le asignamos el primer indice
     * el último valor del array que recibimos por parámetros
     */
    $arrayMod = [];
    $arrayMod[] = $arrayP[count($arrayP) - 1];
    
    /*
     * Ahora solo resta continuar el array normalemente, teniendo
     * en cuenta un detalle; terminar el bucle dos números por debajo
     * de la longitud del array, para que no se imprima el último
     * elemento.
     */
    for ($i = 0; $i < count($arrayP) - 1; $i++) {
        $arrayMod[] = $arrayP[$i];
    }

    /*
     * Printeamos el array modificado usando
     * la función printeoArrays().
     */
    echo "Array Modificado: ";
    echo printeoArrays($arrayMod);
}


/*
 * SEGUNDO EJERCICIO
 * Función que toma un valor como máximo y lo va comparando
 * con el resto de valores del array hasta asegurarnos
 * que el mayor de ellos.
 */
function mayorNumero($arrayP) {
    /*
     * Asignamos el valor de la variable al primer elemento
     * del array, para tomarlo como referencia.
     */
    $max = $arrayP[0];
    
    /*
     * Un for que recorre el elemento desde el índice 1
     * (el índice 0 ya está asignado) y compara con una condición
     * simple de si mi número es menor, entonces lo cambio. Haciendo
     * esto una y otra vez nos aseguramos quedarnos con el mayor de todos.
     */
    for ($i = 1; $i < count($arrayP); $i++) {
        if ($max < $arrayP[$i]) {
            $max = $arrayP[$i];
        }
    }
    
    echo "El nº más grande del array es: $max";
}

// EJERCICIO 1
echo "--- EJERCICIO 1 ---<br>";
echo "Array original: ";
echo printeoArrays($numeros) . "<br>";
arrayMod($numeros);

echo "<br><br>";
// EJERCICIO 2
echo "--- EJERCICIO 2 ---<br>";
mayorNumero($numeros);