<?php
/*
 * Creación de la variable
 */
$fraseOrig = "Antes de criticarme intenta superarme";

/*
 * Función que cambia las letras a mayúsculas o
 * minúsuculas siguiendo un patrón determinado.
 * 
 * La lógica de la función se basa en poner en mayúscula una
 * letra según su índice. Las de índice par van en mayúscula
 * y las de índice impar en minúscula.
 */
function modoCani($frase) {
    /*
     * Creamos la variable que toma el valor del parámetro.
     * Le aplicamos strtolower() directamente para no tenerlo
     * que hacerlo todo en las condiciones. 
     * A su vez dentro del método le aplicamos str_replace. Para
     * seguir la lógica mencionada arriba, lo que se pretende aquí es
     * sustituir el espacio con 2 espacios para que el índice de las
     * letras no cambie.
     */
    $fraseMod = strtolower(str_replace(" ", "  ", $frase));
    /*
     * Creamos un string vacío que iremos rellenando.
     */
    $fraseFinal = "";
    /*
     * El bucle donde aplicamos nuestra lógica.
     * Si $i es par, la ponemos mayúscula, si no la dejamos igual
     * (por eso el strtolower del principio).
     */
    for ($i = 0; $i < strlen($fraseMod); $i++) {
        if ($i % 2 == 0) {
            $fraseFinal .= strtoupper($fraseMod[$i]);
        } else {
            $fraseFinal .= $fraseMod[$i];
        }
    }
    /*
     * Ahora ajustamos de nuevo los espacios para que quede
     * un resultado natural.
     */
    str_replace("  ", " ", $fraseFinal);
    /*
     * Finalmente imprimimos el resultado por pantalla.
     */
    echo $fraseFinal;
}

// EJERCICIO 2
echo "--- EJERCICIO 2 ---<br>";
echo "Frase original: $fraseOrig<br>";
echo "Frase en modo cani: ";
modoCani($fraseOrig);
echo "<br>";