<?php
include "244euros.php";

$producto = $_POST["producto"];
$precio = array_map("floatval", $_POST["precio"]);
$lengthTabla = count($producto);
$totalEur = 0;
$totalPes = 0;

echo "<table border = 1>";

for ($i = 0; $i < $lengthTabla; $i++) {
    echo "<tr>";
    echo "<td>$producto[$i]</td>";
    echo "<td>$precio[$i]</td>";
    echo "<td>" . euros2pesetas($precio[$i]) . "</td>";
    echo "</tr>";
    $totalEur += $precio[$i];
    $totalPes += euros2pesetas($precio[$i]);
}

$totalEur = $totalEur/$lengthTabla;
$totalPes = $totalPes/$lengthTabla;
echo "<tr>";
    echo "<td></td>";
    echo "<td>" . number_format($totalEur, 2) . "</td>";
    echo "<td>" . number_format($totalPes, 2) . "</td>";
echo "</tr>";
echo "</table>";