<?php
include "243biblioteca.php";

$num1 = $_GET["num1"];
$num2 = $_GET["num2"];

$operaciones =[sumar($num1, $num2), restar($num1, $num2),
    multiplicar($num1, $num2), dividir($num1, $num2)
];

for ($i = 0; $i < count($operaciones); $i++) {
    echo $operaciones[$i] . "<br>";
}