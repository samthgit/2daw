<?php
include '246encabezado.php';
include '246pie.php';

$cantidad = $_GET["cantidad"];

echo encabezado();

echo "<form action=\"246listaCompra.php\" method=\"POST\" style=\"border:1px solid black; padding: 10px; border-radius:10px; display: inline-block;\">";
echo "<p style=\"text-align: center; font-weight: bold;\">Tiquet</p>";
for ($i = 0; $i < $cantidad; $i++) {
    echo "<label for=\"producto\">Producto </label><input id=\"producto\" name=\"producto[]\" type=\"text\">";
    echo "<label for=\"precio\"> Precio </label><input id=\"precio\" name=\"precio[]\" type=\"text\">
    <br>";
}
echo "<br>";
echo "<button type=\"submit\">Enviar</button>";
echo "</form>";

echo pie();