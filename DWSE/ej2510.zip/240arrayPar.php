<?php
function esPar($num) {
    if ($num % 2 == 0) {
        return true;
    } else {
        return false;
    }
}

echo esPar(6) . "<br>";

function arrayAleatorio($tam, $min, $max) {
    $arrAl = [];
    for ($i = 0; $i < $tam; $i++) {
        $numRand = rand($min, $max);
        $arrAl[$i] = $numRand;
    }
    return $arrAl;
}

print_r(arrayAleatorio(10, 70, 99));
echo "<br>";

function arrayPares(&$array) {
    $pares = 0;
    for ($i = 0;$i < count($array); $i++) {
        if ($array[$i] % 2 == 0) {
            $pares++;
        }
    }
    return $pares;
}

$miArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
echo arrayPares($miArray) . "<br>";