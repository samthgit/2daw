<?php
function pie() {
    return "<footer>Tu supermercado de confianza</footer>";
}