<?php
include "244euros.php";

echo "Cotización por defecto: " . peseta2euros(100) . "<br>";
echo "Cotización personalizada: " . peseta2euros(100, 0) . "<br>";
echo "<br>";
echo "Cotización por defecto: " . euros2pesetas(10) . "<br>";
echo "Cotización personalizada: " . euros2pesetas(10, 150) . "<br>";