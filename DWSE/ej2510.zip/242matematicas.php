<?php
function digitos($num) {
    $numString = (string)$num;
    return strlen($numString);
}

echo digitos(234) . "<br>";

function digitoN($num, $pos) {
    $numArray = str_split((string)$num);
    return $numArray[$pos-1];
}

echo digitoN(12345467, 5) . "<br>";

function quitaPorDetras($num, $cant) {
    $numArray = str_split((string)$num);
    
    for ($i = 0; $i < $cant; $i++) {
        array_pop($numArray);
    }
    return (int) implode("", $numArray);
}

echo quitaPorDetras(123456, 2) . "<br>";

function quitaPorDelante($num, $cant) {
    $numArray = str_split((string)$num);
    
    for ($i = 0; $i < $cant; $i++) {
        array_shift($numArray);
    }
    return (int) implode("", $numArray);
}

echo quitaPorDelante(123456, 2) . "<br>";