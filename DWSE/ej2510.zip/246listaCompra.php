<?php
include "244euros.php";
include '246encabezado.php';
include '246pie.php';

$producto = $_POST["producto"];
$precio = array_map("floatval", $_POST["precio"]);
$lengthLista = count($producto);

echo "<ul>";
for ($i = 0; $i < $lengthLista; $i++) {
    echo "<li>$producto[$i]: $precio[$i]€/" . number_format(euros2pesetas($precio[$i]), 2) . "pta.</li>";
}

echo "</ul";