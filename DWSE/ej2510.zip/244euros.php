<?php
function peseta2euros($cantidad, $cotizacion = 166.36) {
    if ($cotizacion == 0) {
        return "No se puede dividir por 0";
    } else {
        return $cantidad/$cotizacion;
    }
}

function euros2pesetas($cantidad, $cotizacion = 166.36) {
    return $cantidad*$cotizacion;
}