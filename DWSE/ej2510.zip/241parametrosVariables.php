<?php
function mayor(...$num) {
    $arrayArg = func_get_args();
    $max = $arrayArg[0];
    
    for ($i = 0; $i < count($arrayArg); $i++) {
        if ($max < $arrayArg[$i]) {
            $max = $arrayArg[$i];
        }
    }
    return $max;
}

echo mayor(1, 5, 7, 42, 0, 3, 6, 3, 8) . "<br>";

function concatenar(...$palabras) {
    $arrayPal = func_get_args();
    $strEspac = "";
    
    for ($i = 0; $i < count($arrayPal); $i++) {
        $strEspac .= $arrayPal[$i] . " ";
    }
    return $strEspac;
}

echo concatenar("Hola", "buenos", "dias", "que", "tal") . "<br>";