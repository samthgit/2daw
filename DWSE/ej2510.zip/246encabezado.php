<?php
function encabezado() {
    return "<h1>Supermercado Severo</h1>";
}