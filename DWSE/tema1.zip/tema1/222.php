<?php
$base = 2;
$exponente = 4;
$potencia = $base;

for ($i = 1; $i < $exponente; $i++) {
    $potencia *= $base;
}

echo "$base^$exponente = $potencia";