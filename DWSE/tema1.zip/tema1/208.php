<?php
$numero = 0;

if ($numero > 0) {
    echo "El número es positivo";
} elseif ($numero < 0) {
    echo "El número es negativo";
} else {
    echo "El número es 0";
}