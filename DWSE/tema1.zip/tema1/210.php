<?php
$edad = 91;

if ($edad < 3) {
    echo "Es un bebé";
} elseif ($edad >= 3 && $edad <= 12) {
    echo "Es un niño";
} elseif ($edad >= 13 && $edad <= 17) {
    echo "Es un adolescente";
} elseif ($edad >= 18 && $edad <= 66) {
    echo "Es un adulto";
} elseif ($edad >= 67) {
    echo "Es un jubilado";
}