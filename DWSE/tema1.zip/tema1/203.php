<?php

$nombre = "Samuel";
$apellidos = "Tineo Herrera";
$email = "samtineo@gmail.com";
$anoNac = 2000;
$tlf = 987654321;
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<table>
	<tr>
		<td>Nombre</td>
		<td><?php echo $nombre?></td>
	</tr>
	<tr>
		<td>Apellidos</td>
		<td><?php echo $apellidos?></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><?php echo $email?></td>
	</tr>
	<tr>
		<td>Año de Nacimiento</td>
		<td><?php echo $anoNac?></td>
	</tr>
	<tr>
		<td>Teléfono</td>
		<td><?php echo $tlf?></td>
	</tr>
    </table>

</body>
</html>