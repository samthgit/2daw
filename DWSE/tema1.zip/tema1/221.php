<?php
$suma = 0;

for ($i = 1; $i <= 10; $i++) {
    $suma += $i;
}

echo "La suma total de 1 a 10 es $suma";