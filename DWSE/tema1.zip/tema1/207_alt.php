<?php
$valor = 1439;

$bill500 = 0;
$bill200 = 0;
$bill100 = 0;
$bill50 = 0;
$bill20 = 0;
$bill10 = 0;
$bill5 = 0;
$mon2 = 0;
$mon1 = 0;

// 500
while ($valor >= 500) {
    $valor -= 500;
    $bill500++;
}

echo "$bill500 billete de 500<br>";

// 200
while ($valor >= 200) {
    $valor -= 200;
    $bill200++;
}

echo "$bill200 billete de 200<br>";

// 100
while ($valor >= 100) {
    $valor -= 100;
    $bill100++;
}

echo "$bill100 billete de 100<br>";

// 50
while ($valor >= 50) {
    $valor -= 50;
    $bill50++;
}

echo "$bill50 billete de 50<br>";

// 20
while ($valor >= 20) {
    $valor -= 20;
    $bill20++;
}

echo "$bill20 billete de 20<br>";

// 10
while ($valor >= 10) {
    $valor -= 10;
    $bill10++;
}

echo "$bill10 billete de 10<br>";

// 5
while ($valor >= 5) {
    $valor -= 5;
    $bill5++;
}

echo "$bill5 billete de 5<br>";

// 2
while ($valor >= 2) {
    $valor -= 2;
    $mon2++;
}

echo "$mon2 moneda de 2<br>";

// 1
while ($valor >= 1) {
    $valor -= 1;
    $mon1++;
}

echo "$mon1 moneda de 1<br>";
