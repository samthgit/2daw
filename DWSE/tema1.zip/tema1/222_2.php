<?php
$base = 2;
$exponente = 4;
$potencia = $base;
$i = 1;

do {
    $potencia *= $base;
    $i++;
} while ($i < $exponente);

echo "$base^$exponente = $potencia";