<?php
$x = 166;
$y = 999;

echo "$x $y<br>";
echo $x + $y . "<br>";
echo $x - $y . "<br>";
echo $x / $y . "<br>";
echo $x * $y . "<br>";