<?php
$suma = $_POST["suma"];
$sumaTotal = 0;

for ($i = 0; $i < count($suma); $i++) {
    $sumaTotal +=$suma[$i];
}

echo "La suma total de los campos es: $sumaTotal";