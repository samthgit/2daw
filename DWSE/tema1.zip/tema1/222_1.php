<?php
$base = 2;
$exponente = 4;
$potencia = $base;
$i = 1;

while ($i < $exponente) {
    $potencia *= $base;
    $i++;
}

echo "$base^$exponente = $potencia";