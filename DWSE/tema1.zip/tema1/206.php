<?php
$edad = $_GET["edad"];
$anyoActual = date("Y");
$auxEdJub = 67 - $edad;

echo "Edad dentro de 10 años: " . $edad + 10 . " y será el año " . $anyoActual + 10 . "<br>";
echo "Edad hace 10 años: " . $edad - 10 . " y fue el año " . $anyoActual - 10 . "<br>";
echo "Cuando te jubiles será el año " . $anyoActual + $auxEdJub;