<?php
$hora = 17;
$minuto = 34;
$segundo = 12;

if (($segundo == 59) && ($minuto == 59) && ($hora == 23)) {
    $hora = 0;
    $minuto = 0;
    $segundo = 0;
    
} elseif (($segundo == 59) && ($minuto == 59)) {
    $hora++;
    $minuto = 0;
    $segundo = 0;
} elseif ($segundo == 59) {
    $minuto++;
    $segundo = 0;
} else {
    $segundo++;
}

echo "La hora dentro de un segundo sera $hora:$minuto:$segundo";