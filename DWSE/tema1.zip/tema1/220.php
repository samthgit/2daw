<?php
echo "<ul>";
for ($i = 0; $i <= 50; $i++) {
    if ($i % 2 == 0) {
        echo "<li>$i</li>";
    }
}
echo "</ul>";