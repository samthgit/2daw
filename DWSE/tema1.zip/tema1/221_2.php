<?php

$inicio = 12;
$fin = 36;
$suma = 0;

for ($i = $inicio; $i <= $fin; $i++) {
    $suma += $i;
}

echo "La suma total de $inicio a $fin es $suma";