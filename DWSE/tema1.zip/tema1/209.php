<?php
$a = 99;
$b = 78;
$c = 10;

if (($a > $b) && ($a > $c)) {
    echo "$a es el mayor de los números";
} elseif (($b > $a) && ($b > $c)) {
    echo "$b es el mayor de los números";
} elseif (($c > $a) && ($c > $b)) {
    echo "$c es el mayor de los números";
}