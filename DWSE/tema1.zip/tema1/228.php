<?php
/*
 * para ejecutarlo recuerda poner
 * en la url: ./228.php?=tunumero
 */
$a = $_GET["a"];

echo "<style> table{
    border: 1px solid gray;
    border-collapse: collapse;
    font-family: Arial;
}
    td, th {
    border-top: 1px solid gray;
    padding: 5px 40px 5px 5px;
    
}
</style>";

$encabezado = ["a", "*", "b", "=", "a*b"];

echo "<table>";

echo "<thead>";
for($i = 0; $i < count($encabezado); $i++) {
    $valor = $encabezado[$i];
    echo "<th>$valor</th>";
}

echo "</thead>";
echo "<tbody>";
for ($i = 1; $i <= 10; $i++) {
    echo "<tr>";
    echo "<td>$a</td>";
    echo "<td>*</td>";
    echo "<td>$i</td>";
    echo "<td>=</td>";
    echo "<td>". $a*$i. "</td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table";