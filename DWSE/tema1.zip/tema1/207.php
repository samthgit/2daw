<?php
$valor = 1439;

$valAux = intdiv($valor, 500);
echo "$valAux billetes de 500<br>";
$valor %= 500;

$valAux = intdiv($valor, 200);
echo "$valAux billetes de 200<br>";
$valor %= 200;

$valAux = intdiv($valor, 100);
echo "$valAux billetes de 100<br>";
$valor %= 100;

$valAux = intdiv($valor, 50);
echo "$valAux billetes de 50<br>";
$valor %= 50;

$valAux = intdiv($valor, 20);
echo "$valAux billetes de 20<br>";
$valor %= 20;

$valAux = intdiv($valor, 10);
echo "$valAux billetes de 10<br>";
$valor %= 10;

$valAux = intdiv($valor, 5);
echo "$valAux billetes de 5<br>";
$valor %= 5;

$valAux = intdiv($valor, 2);
echo "$valAux monedas de 2<br>";
$valor %= 2;

$valAux = intdiv($valor, 1);
echo "$valAux monedas de 1<br>";
$valor %= 1;