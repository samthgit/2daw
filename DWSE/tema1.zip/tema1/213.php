<?php
$a = 3;
$b = 4;
$c = 1;

$disc = pow($b, 2) - 4*$a*$c;

$ecPos = (-$b + sqrt($disc)) / (2*$a);
$ecNeg = (-$b - sqrt($disc)) / (2*$a);

if ($disc < 0) {
    echo "La ecuación no tiene solución";
} else {
    echo "La solución del positivo es: $ecPos<br>";
    echo "La solución del negativo es: $ecNeg<br>";
}