<?php
$dia = 12;
$mes = 5;
$anyo = 2024;


if ($mes == 12 && $dia == 31) {
    $anyo++;
    $mes = 1;
    $dia = 1;
} elseif (($mes == 1 || $mes == 3 || $mes == 5 || $mes == 7 || $mes == 8 || $mes == 10) && $dia == 31) {
    $mes++;
    $dia = 1;
} elseif (($mes == 4 || $mes == 6 || $mes == 9 || $mes == 11) && $dia == 30) {
    $mes++;
    $dia = 1;
} elseif (($mes == 2) && $dia == 28) {
    $mes++;
    $dia = 1;
} else {
    $dia++;
}

echo "La fecha dentro de un día será $dia/$mes/$anyo";