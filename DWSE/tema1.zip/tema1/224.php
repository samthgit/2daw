<?php
$cantidad = $_POST["cant"];

echo "<form action=\"224_2.php\" method=\"POST\" style=\"border:1px solid black; padding: 10px; border-radius:10px; display: inline-block;\">";
for ($i = 0; $i < $cantidad; $i++) {
    $aux = $i + 1;
    echo "<label for=\"cant\">Cantidad $aux</label><input id=\"cant\" name=\"suma[]\" type=\"number\">
    <br>";
}

echo "<button type=\"submit\">Enviar</button>";
echo "</form>";