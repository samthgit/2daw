<?php
/*
 * para ejecutarlo recuerda poner
 * en la url: ./223.php?=tunumero
 */
$a = $_GET["a"];

echo "<style> table, td, th{
    border: 1px solid gray;
}
</style>";

$encabezado = ["a", "*", "b", "=", "a*b"];

echo "<table>";

echo "<thead>";
for($i = 0; $i < count($encabezado); $i++) {
    $valor = $encabezado[$i];
    echo "<th>$valor</th>";
}

echo "</thead>";
echo "<tbody>";
for ($i = 1; $i <= 10; $i++) {
    echo "<tr>";
    echo "<td>$a</td>";
    echo "<td>*</td>";
    echo "<td>$i</td>";
    echo "<td>=</td>";
    echo "<td>". $a*$i. "</td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table";