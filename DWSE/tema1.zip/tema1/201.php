<?php
echo "Hola mundo <br>";
print "Hola otra vez";

/* Comentario
 * de
 * bloque
 */ 

// Comentario de línea