<?php
// Array con usuarios y contraseñas hasheadas (simulación de base de datos)
$usuarios = [
    'usuario' => 'usuario' // Contraseña: "usuario" hasheada con bcrypt
];
?>