<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Formulario 415</title>
</head>
<body>
<h1>Iniciar sesión</h1>
<form action="415_login.php" method="post">
<label for="username">Usuario:</label>
<input type="text" name="username" id="username" required><br><br>
<label for="password">Contraseña:</label>
<input type="password" name="password" id="password" required><br><br>
<input type="submit" value="Iniciar sesión">
</form>
</body>
</html>
